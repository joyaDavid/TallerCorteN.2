
package dao;

public class HuespedDAO {
    
}
