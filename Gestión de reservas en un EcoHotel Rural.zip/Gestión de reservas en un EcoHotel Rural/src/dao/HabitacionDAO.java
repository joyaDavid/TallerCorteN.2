package dao;

import dto.HabitacionDTO;
import java.util.ArrayList;

public class HabitacionDAO {

    private ArrayList<HabitacionDTO> habitacion = new ArrayList<>();

    public HabitacionDAO() {
        this.habitacion = habitacion;
    }

    public boolean guardarHabitacion(HabitacionDTO getdocumento){
            habitacion.add(getdocumento);
            return false;
    }

    public boolean limpiarHabitacion(HabitacionDTO habitaciones ) {
        for (int i = 0; i < habitacion.size(); i++) {
            habitacion.remove(i);
        }
        return false;
    }
}
