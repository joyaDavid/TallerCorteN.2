
package dto;

public class IDGeneradorDTO {
    
}
