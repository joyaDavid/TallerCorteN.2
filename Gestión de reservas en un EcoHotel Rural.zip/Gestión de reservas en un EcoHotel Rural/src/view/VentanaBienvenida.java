
package view;

import javax.swing.SwingUtilities;
import dto.HabitacionDTO;
import javax.swing.JFrame;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.ArrayList;

public class VentanaBienvenida extends javax.swing.JFrame {


public class FormHabitacion extends JFrame {

    private final JSpinner spnNumero;
    private final JSpinner spnCapacidad;
    private final JComboBox<String> cbTipo;
    private final JComboBox<String> cbEstado;
    private final JButton btnGuardar;
    private final JButton btnLimpiar;
    private final JTable tabla;
    private final DefaultTableModel modeloTabla;

    private ArrayList<HabitacionDTO> listaHabitaciones = new ArrayList<>();

    public FormHabitacion() {
        setTitle("Gestión de Habitaciones");
        setSize(500,300);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

    
        JPanel panelDatos = new JPanel(new GridLayout(5, 2, 10, 10));

        panelDatos.add(new JLabel("Número:"));
        spnNumero = new JSpinner(new SpinnerNumberModel(1, 1, 1000, 1));
        panelDatos.add(spnNumero);

        panelDatos.add(new JLabel("Tipo:"));
        cbTipo = new JComboBox<>(new String[]{"Individual", "Doble", "Suite"});
        panelDatos.add(cbTipo);

        panelDatos.add(new JLabel("Capacidad:"));
        spnCapacidad = new JSpinner(new SpinnerNumberModel(1, 1, 10, 1));
        panelDatos.add(spnCapacidad);

        panelDatos.add(new JLabel("Estado:"));
        cbEstado = new JComboBox<>(new String[]{"Disponible", "Ocupada", "Mantenimiento"});
        panelDatos.add(cbEstado);

        
        btnGuardar = new JButton("Guardar");
        btnLimpiar = new JButton("Limpiar");

        panelDatos.add(btnGuardar);
        panelDatos.add(btnLimpiar);

        add(panelDatos, BorderLayout.NORTH);

       
        modeloTabla = new DefaultTableModel(new String[]{"Número", "Tipo", "Capacidad", "Estado"}, 0);
        tabla = new JTable(modeloTabla);
        add(new JScrollPane(tabla), BorderLayout.CENTER);

        
        btnGuardar.addActionListener(e -> guardarHabitacion());
        btnLimpiar.addActionListener(e -> limpiarCampos());
    }

    private void guardarHabitacion() {
        int numero = (int) spnNumero.getValue();
        String tipo = (String) cbTipo.getSelectedItem();
        int capacidad = (int) spnCapacidad.getValue();
        String estado = (String) cbEstado.getSelectedItem();

        HabitacionDTO hab = new HabitacionDTO(estado, estado, estado, estado);
        listaHabitaciones.add(hab);

        modeloTabla.addRow(new Object[]{numero, tipo, capacidad, estado});
        JOptionPane.showMessageDialog(this, "Habitación guardada correctamente.");
    }

    private void limpiarCampos() {
        spnNumero.setValue(1);
        cbTipo.setSelectedIndex(0);
        spnCapacidad.setValue(1);
        cbEstado.setSelectedIndex(0);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new FormHabitacion().setVisible(true);
        });
    }
}
    // Getters si los necesitas
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(VentanaBienvenida.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(VentanaBienvenida.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(VentanaBienvenida.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(VentanaBienvenida.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new VentanaBienvenida().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables
}

