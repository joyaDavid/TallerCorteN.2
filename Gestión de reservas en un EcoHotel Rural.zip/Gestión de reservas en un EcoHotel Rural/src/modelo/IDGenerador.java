
package modelo;

public class IDGenerador extends AbstractMethodError {
    
    public static int contador = 1;
    
    public static String generateReservaid(){
       
    String id = "RES-" + contador ;
    contador++;
    return id;
   }    
}
